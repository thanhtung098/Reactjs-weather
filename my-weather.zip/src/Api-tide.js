import axios from 'axios'
const KEY = '81216061-401f-4d66-9605-60e0d4099286';

export default axios.create({
    // baseURL: '../data.json',
})